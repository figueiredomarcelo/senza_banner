# Banner

Play video with an advertising banner, and switch between the local and remote players.

See the [Playing Video](https://developer.synamedia.com/senza/docs/playing-video) tutorial in the Senza developer documentation.

## Build

```bash
npm ci
npx webpack -w --config webpack.config.js
open index.html
```
